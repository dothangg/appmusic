import 'package:flutter/cupertino.dart';
import 'package:music_app1/ui/home/home.dart';

void main() => runApp(const MusicApp1());